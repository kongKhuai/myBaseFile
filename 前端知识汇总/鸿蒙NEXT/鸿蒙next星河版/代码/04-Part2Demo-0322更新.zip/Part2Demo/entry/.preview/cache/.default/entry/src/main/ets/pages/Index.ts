interface Index_Params {
    count?: number;
    oldPrice?: number;
    newPrice?: number;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__count = new ObservedPropertySimplePU(5, this, "count");
        this.__oldPrice = new ObservedPropertySimplePU(40.4, this, "oldPrice");
        this.__newPrice = new ObservedPropertySimplePU(10.4, this, "newPrice");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.count !== undefined) {
            this.count = params.count;
        }
        if (params.oldPrice !== undefined) {
            this.oldPrice = params.oldPrice;
        }
        if (params.newPrice !== undefined) {
            this.newPrice = params.newPrice;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__count.purgeDependencyOnElmtId(rmElmtId);
        this.__oldPrice.purgeDependencyOnElmtId(rmElmtId);
        this.__newPrice.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__count.aboutToBeDeleted();
        this.__oldPrice.aboutToBeDeleted();
        this.__newPrice.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 核心思路:
    // 1. 提取状态: 数量, 原价, 现价
    // 2. 结合状态渲染
    // 3. 修改状态, 界面自动更新
    private __count: ObservedPropertySimplePU<number>;
    get count() {
        return this.__count.get();
    }
    set count(newValue: number) {
        this.__count.set(newValue);
    }
    private __oldPrice: ObservedPropertySimplePU<number>;
    get oldPrice() {
        return this.__oldPrice.get();
    }
    set oldPrice(newValue: number) {
        this.__oldPrice.set(newValue);
    }
    private __newPrice: ObservedPropertySimplePU<number>;
    get newPrice() {
        return this.__newPrice.get();
    }
    set newPrice(newValue: number) {
        this.__newPrice.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(12:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f3f3f3');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(13:7)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 产品
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(15:9)");
            // 产品
            Row.width('100%');
            // 产品
            Row.alignItems(VerticalAlign.Top);
            // 产品
            Row.padding(20);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.part2demo", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(17:11)");
            // 图片
            Image.width(100);
            // 图片
            Image.borderRadius(8);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 文字
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(21:11)");
            // 文字
            Column.height(75);
            // 文字
            Column.layoutWeight(1);
            // 文字
            Column.justifyContent(FlexAlign.SpaceBetween);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 6 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(22:13)");
            Column.width('100%');
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('冲销量1000ml缤纷八果水果捞');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(23:15)");
            Text.lineHeight(20);
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('含1份折扣商品');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(26:15)");
            Text.fontSize(12);
            Text.fontColor('#7f7f7f');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(32:13)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 价格
            Row.create({ space: 5 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(34:15)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Index.ets(35:17)");
            Text.fontColor('#ff4000');
        }, Text);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('￥');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(36:19)");
            Span.fontSize(14);
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create(this.newPrice.toFixed(2));
            Span.debugLine("entry/src/main/ets/pages/Index.ets(38:19)");
            Span.fontSize(18);
        }, Span);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Index.ets(42:17)");
            Text.fontSize(14);
            Text.fontColor('#999');
            Text.decoration({ type: TextDecorationType.LineThrough, color: '#999' });
        }, Text);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('￥');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(43:19)");
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create(this.oldPrice.toFixed(2));
            Span.debugLine("entry/src/main/ets/pages/Index.ets(44:19)");
        }, Span);
        Text.pop();
        // 价格
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 加减
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(51:15)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('-');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(52:17)");
            Text.width(22);
            Text.height(22);
            Text.border({ width: 1, color: '#e1e1e1', radius: { topLeft: 5, bottomLeft: 5 } });
            Text.textAlign(TextAlign.Center);
            Text.fontWeight(700);
            Text.onClick(() => {
                // this.count = this.count - 1
                // 让状态变量,在原有数据的基础上自减1
                this.count--;
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.count.toString());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(63:17)");
            Text.height(22);
            Text.border({ width: { top: 1, bottom: 1 }, color: '#e1e1e1' });
            Text.padding({ left: 10, right: 10 });
            Text.fontSize(14);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('+');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(68:17)");
            Text.width(22);
            Text.height(22);
            Text.border({ width: 1, color: '#e1e1e1', radius: { topRight: 5, bottomRight: 5 } });
            Text.textAlign(TextAlign.Center);
            Text.fontWeight(700);
            Text.onClick(() => {
                this.count++;
            });
        }, Text);
        Text.pop();
        // 加减
        Row.pop();
        Row.pop();
        // 文字
        Column.pop();
        // 产品
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 结算
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(91:9)");
            // 结算
            Row.width('100%');
            // 结算
            Row.height(70);
            // 结算
            Row.backgroundColor('#fff');
            // 结算
            Row.position({ x: 0, y: '100%' });
            // 结算
            Row.translate({ y: '-100%' });
            // 结算
            Row.padding({ left: 20, right: 20 });
            // 结算
            Row.justifyContent(FlexAlign.End);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 价格
            Column.create({ space: 5 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(93:11)");
            // 价格
            Column.alignItems(HorizontalAlign.End);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Index.ets(94:13)");
            Text.fontSize(14);
        }, Text);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create(`已选 ${this.count} 件，`);
            Span.debugLine("entry/src/main/ets/pages/Index.ets(95:15)");
            Span.fontColor('#848484');
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('合计:');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(97:15)");
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('￥');
            Span.debugLine("entry/src/main/ets/pages/Index.ets(98:15)");
            Span.fontColor('#fd4104');
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create((this.count * this.newPrice).toFixed(2));
            Span.debugLine("entry/src/main/ets/pages/Index.ets(100:15)");
            Span.fontColor('#fd4104');
            Span.fontSize(16);
        }, Span);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('共减￥' + (this.count * (this.oldPrice - this.newPrice)).toFixed(2));
            Text.debugLine("entry/src/main/ets/pages/Index.ets(105:13)");
            Text.fontColor('#fd4104');
            Text.fontSize(12);
        }, Text);
        Text.pop();
        // 价格
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 结算按钮
            Button.createWithLabel('结算外卖');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(111:11)");
            // 结算按钮
            Button.width(110);
            // 结算按钮
            Button.height(40);
            // 结算按钮
            Button.backgroundColor('#fed70e');
            // 结算按钮
            Button.fontColor('#564200');
            // 结算按钮
            Button.fontSize(16);
            // 结算按钮
            Button.fontWeight(600);
        }, Button);
        // 结算按钮
        Button.pop();
        // 结算
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.part2demo", moduleName: "entry", pagePath: "pages/Index" });
