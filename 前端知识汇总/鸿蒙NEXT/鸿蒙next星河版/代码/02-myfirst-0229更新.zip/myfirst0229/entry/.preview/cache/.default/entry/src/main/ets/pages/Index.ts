interface Index_Params {
    message?: string;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('学鸿蒙来黑马', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // backgroundImagePosition
            // 1. 传入对象, 设置位置坐标，背景图片的左顶点
            //    { x: 坐标值, y: 坐标值 }
            //    注意：坐标值的单位，和宽高的默认单位不同的，显示出来大小会不同
            //
            // 2. Alignment 枚举，设置一些特殊的位置（中央、左顶点...）
            //    Center  TopStart左顶点 TopEnd右顶点 BottomEnd右下...
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(13:5)");
            // backgroundImagePosition
            // 1. 传入对象, 设置位置坐标，背景图片的左顶点
            //    { x: 坐标值, y: 坐标值 }
            //    注意：坐标值的单位，和宽高的默认单位不同的，显示出来大小会不同
            //
            // 2. Alignment 枚举，设置一些特殊的位置（中央、左顶点...）
            //    Center  TopStart左顶点 TopEnd右顶点 BottomEnd右下...
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Index.ets(14:7)");
            Text.width('300vp');
            Text.height('200vp');
            Text.backgroundColor(Color.Pink);
            Text.backgroundImage({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Text.backgroundImagePosition({
                x: vp2px(150),
                y: vp2px(100)
            });
        }, Text);
        Text.pop();
        // backgroundImagePosition
        // 1. 传入对象, 设置位置坐标，背景图片的左顶点
        //    { x: 坐标值, y: 坐标值 }
        //    注意：坐标值的单位，和宽高的默认单位不同的，显示出来大小会不同
        //
        // 2. Alignment 枚举，设置一些特殊的位置（中央、左顶点...）
        //    Center  TopStart左顶点 TopEnd右顶点 BottomEnd右下...
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myfirst", moduleName: "entry", pagePath: "pages/Index" });
