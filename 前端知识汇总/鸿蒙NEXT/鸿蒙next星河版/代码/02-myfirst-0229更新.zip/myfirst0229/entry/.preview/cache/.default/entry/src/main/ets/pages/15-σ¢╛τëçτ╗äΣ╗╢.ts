interface Index_Params {
    message?: string;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('学鸿蒙来黑马', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 1. 网络图片加载 Image('网图地址')
            // Column() {
            //   Image('https://www.itheima.com/images/logo.png')
            //     .height(50)
            // }
            // 2. 本地图片加载  Image( $r('app.media.文件名') )
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/15-\u56FE\u7247\u7EC4\u4EF6.ets(16:5)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/15-\u56FE\u7247\u7EC4\u4EF6.ets(17:7)");
            Image.width(200);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('耐克龙年限定款！！！');
            Text.debugLine("entry/src/main/ets/pages/15-\u56FE\u7247\u7EC4\u4EF6.ets(19:7)");
            Text.width(200);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/15-\u56FE\u7247\u7EC4\u4EF6.ets(21:7)");
            Row.width(200);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/15-\u56FE\u7247\u7EC4\u4EF6.ets(22:9)");
            Image.width(20);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('令人脱发的代码');
            Text.debugLine("entry/src/main/ets/pages/15-\u56FE\u7247\u7EC4\u4EF6.ets(24:9)");
        }, Text);
        Text.pop();
        Row.pop();
        // 1. 网络图片加载 Image('网图地址')
        // Column() {
        //   Image('https://www.itheima.com/images/logo.png')
        //     .height(50)
        // }
        // 2. 本地图片加载  Image( $r('app.media.文件名') )
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myfirst", moduleName: "entry", pagePath: "pages/15-\u56FE\u7247\u7EC4\u4EF6" });
