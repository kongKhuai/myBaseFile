interface Index_Params {
    message?: string;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('学鸿蒙来黑马', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 构建界面核心思路：
            // 1. 排版（思考布局）
            // 2. 内容 (基础组件)
            // 3. 美化 (属性方法)
            Column.create({ space: 15 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(10:5)");
            // 构建界面核心思路：
            // 1. 排版（思考布局）
            // 2. 内容 (基础组件)
            // 3. 美化 (属性方法)
            Column.width('100%');
            // 构建界面核心思路：
            // 1. 排版（思考布局）
            // 2. 内容 (基础组件)
            // 3. 美化 (属性方法)
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777227, "type": 20000, params: [], "bundleName": "com.example.myfirst", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(11:7)");
            Image.width(50);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({
                placeholder: '请输入用户名'
            });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(13:7)");
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({
                placeholder: '请输入密码'
            });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(16:7)");
            TextInput.type(InputType.Password);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('登录');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(19:7)");
            Button.width('100%');
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 15 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(21:7)");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('前往注册');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(22:9)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('忘记密码');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(23:9)");
        }, Text);
        Text.pop();
        Row.pop();
        // 构建界面核心思路：
        // 1. 排版（思考布局）
        // 2. 内容 (基础组件)
        // 3. 美化 (属性方法)
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myfirst", moduleName: "entry", pagePath: "pages/Index" });
